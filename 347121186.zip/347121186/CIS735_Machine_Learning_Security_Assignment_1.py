#!/usr/bin/env python
# coding: utf-8

# # CIS 735 Machine Learning for Computer Security
# ## Assignment 1
# ### Submitted by: Hemaleka Mohanram
# ### SUID: 347121186

# ## About the Dataset
# 
# ### * The zipped file “DataCIS735_Assignment1.zip” contains the data samples for this assignment.                 These are sourced from SU-AIS BB-MAS dataset1, the entire dataset can be accessed at http://dx.doi.org/10.21227/rpaz-0h66.                                                                                                                             There are five samples each, for “User A” and “User B” (total: ten files), in the “DataSamples” folder.               There are three test-samples that are labelled “Test1”, “Test2”, and “Test3”, in the “TestSamples” folder.            
# 
# ### The “Demographics.csv” file contains demographic information about user A and B. 
# ### Each sample consists of about two seconds of walking data (this is known as windowing approach, data provided is already split into two second windows) collected by the phone in user’s pocket. 
# 
# ### For this assignment we will only use the data from the accelerometer. The accelerometer files have five columns, "EID": event ID (Integer); "Xvalue", "Yvalue", "Zvalue": the acceleration force in m/s2 on x, y and z axes respectively, excluding the force of gravity (Float); and "time": the timestamp of the data point (String in date-time format with millisecond resolution).

# ## Import all necessary packages

# In[1]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# ## Part A (10 Points): Basics and Visualization
# ###  *  a) Plot two data samples, one from each User. The plots must have accelerometer signals from X, Y, Z axes, a legend and title (the sample file name).
# ###  * b) In a separate graph, plot the density curves of the "Xvalue" columns from the two samples.
# ###  * c) Provide a summary of your observations from the plots. Summary need not be highly technical in nature; this is a practice to articulate insights from visualizing data. 

# ### Understanding the data

# In[2]:


data_sample_path = "C:\\Users\\hemal\\Desktop\\Masters\\SEM3\\Machine Learning\\Assignment\\Assignment1\\DataCIS735_Assignment1\\DataSamples"
# data_sample_path = give_folder_path 


# In[3]:


def read_df(data_sample_path):
    alldf={}
    # Reading the data
    for file_path in os.listdir(data_sample_path): 
        print ("Read the File for " + file_path)
        name = file_path[:-4] # just taking the file name ignoring the .csv part
        location =data_sample_path+"\\"+file_path
        alldf[name] = pd.read_csv(location,index_col="EID")
    return (alldf)


# In[4]:


alldf = read_df(data_sample_path)


# In[5]:


print(alldf)#['UserA_1']


# In[6]:


def understanding_data(alldf):
    # im just looping over all files inside the data sample folder
    for i, user in enumerate(alldf.keys()):
        df = alldf[user]
        print("########################")
        print("Sample of Data for {}".format(user))
        print("########################")
        print(df.head())

        print("########################")
        print("ABOUT THE DATA")
        print("########################")
        print(df.info())

        print("########################")
        print("UNDERSTANDING THE NUMERICAL VARIABLE")
        print("########################")

        print(df.describe())
        print("########################")

        ## PLOTING
        print("PLOTING THE DATAFRAME")
        df=df.reset_index(drop=True)

        #plot
        # if possible do it in subplot
        lines=df.plot.hist()
        lines=df.plot.box()
        lines=df.plot.line()
        save_fig = user + ".png"
        plt.savefig(save_fig)

        plt.xlabel('Index')
        plt.ylabel('Accelerometer signals')

        plt.title(user)
        plt.legend()
        plt.show()
        plt.clf()


# ### Understanding the dataset of 2 users "UserA_1","UserB_1"

# In[7]:


only2UserValues = dict([(key, alldf[key]) for key in ["UserA_1","UserB_1"]])
understanding_data(only2UserValues)


# In[8]:


## To Understand the data of all csvs use the below code
understanding_data(alldf)


# ## Density curve of samples
# 
# ### Density curve is the distribution of the values - here "Xvalues

# In[9]:


# Plotting the density curve of users
# For all Users use the below for loop

for i, user in enumerate(alldf.keys()):
    sns.distplot(alldf[user]['Xvalue'], hist = False, kde = True, kde_kws = {'linewidth': 2},label = str(user))

plt.legend(prop={'size': 12}, title = 'Accelerometer')
plt.title('Density Plot for All Users')
plt.xlabel('Accelerometer X value ')
plt.ylabel('Density')
plt.savefig("DensityCurvesAllUsers.png")
plt.show()
    
# For UserA_1 and UserB_1 only use below
for i, user in enumerate(["UserA_1","UserB_1"]):

    sns.distplot(alldf[user]['Xvalue'], hist = False, kde = True, kde_kws = {'linewidth': 2},label = str(user))

plt.legend(prop={'size': 12}, title = 'Accelerometer')
plt.title('Density Plot for UserA_1 and UserB_1')
plt.xlabel('Accelerometer X value ')
plt.ylabel('Density')
plt.savefig("DensityCurvesUA1_UB1.png")
plt.show()


# ## SUMMARY OF OBSERVATION

# ### From the line graph of Xvalue, Yvalue, Zvalue of USERA_1, I find that at the index value between 63 - 68 and 179 - 182 the X value suddenly varies a lot. Z value between index 80 - 82 and 193 - 195 also suddenly drops at 175 index all three values superimpose
# 
# #### The sudden drop can be a outlier point but it can only be decided based on the context 
# 
# ### If we see the box plot graphs, we can find that for X, Y, Z  values there are many values below lower extreme and upper extreme  
# #### Those points can be potential outliers 
# 
# ### From the graph of Xvalue, Yvalue, Zvalue of USERB_1, I find that at the index value at 27 Y and Zvalues drop suddenly at 47 Y value suddenly increases at 162 Y and Z value superimpose and decrease where as X value increases. Between 25 - 75 100-125, 160-175 Y value fluctuates heavyly  
# 
# #### The fluctuations can be noise in the dataset
# 
# 

# ### From the density curve, I find that:
# * For USER A the distribution of X value is between -20 to 10 with more values at around -6  
# * For USERB, the X values varies between -10 and 10 with peak value at around 0

# ## Part B (30 Points): Feature Design, Description and Extraction (to be performed on all data samples)
# ### a) Design and describe at least 5 features (or more) to be extracted from each (X,Y, Z) columns of the data-samples.
# ### b) Write a program to extract the 5 features (or more) from each data-sample and store them in a single file named “Features.csv” with the following format: 
# ####   User Sample no. <Feature_1> <Feature_2> .. .. <Feature_n> Where, “User” is A or B, “Sample no.” is the data-sample file number, and <Feature_1> to <Feature_n> are feature values extracted from the sample (label the feature columns accordingly, for example if feature is “mean” of Xvalue , then label the feature “mean_X”)
# ### c) Provide a summary of your observations from tasks in part B:
# ####  a. Why did you choose the features that you did?
# ####  b. What are other features that can be explored for this data?
# ####  c. Do you think the selected features would work for all forms of data, why or why not?

# ### PART a, b Feature Extraction:
# #### I'm planning to extract, Mean, std, var, max, SUm for each column

# In[10]:



def feature_extraction(alldf,name):
    features=["Mean_X","std_X","Var_X","max_X","sum_X","Mean_X","std_Y","Var_Y","max_Y","sum_Y","Mean_Z","std_Z","Var_Z","max_Z","sum_Z"]

    feature_df = []

    #looping over each file
    for i, user in enumerate(alldf.keys()):
        feature_vector=[]
        # looping over each column 
        for column in alldf[user].columns[:-1]:
            feature_vector.extend([alldf[user][column].mean(),alldf[user][column].std(),alldf[user][column].var(),alldf[user][column].max(),alldf[user][column].sum() ])

        #print(feature_vector)

        feature_vector=[user] + feature_vector
        feature_df.append(feature_vector)

    Final_feature_df=pd.DataFrame(data=feature_df,columns=["User"]+features)

    print(Final_feature_df)

    # Wrting the feature to csv file
    feature_name = name + ".csv"
    Final_feature_df.to_csv(feature_name,index=False)
    print("###########################")
    print("Saving the {}".format(feature_name))
    print("###########################")
    return Final_feature_df


# In[11]:


Final_feature_alldf =feature_extraction(alldf,name = "FeaturesDF")


# ## Part c
# ### a. Why did you choose the features that you did?
# * Since it is a numerical column, I took these features like mean, standard deviation, variance, maximum, sum these features  will help us understand our numeric column and distribution
# ###  b. What are other features that can be explored for this data?
# * We can try other features like IQR inter Quantile range, distance between X,Y,Z value points etc , Squareroot, Log value etc
# ###  c. Do you think the selected features would work for all forms of data, why or why not?
# * All these selected features will work only for numeric data and Non Null values 

# ## Part C (30 Points): Distance Measures, Measuring Similarities or Dissimilarities
# ### a) List and describe at least 2 distance measures that can be used to measure similarities or dissimilarities between the feature vectors (rows) in “Features.csv”.
# 
# ### b) Write a program to implement the two distance measures to measure distances between each feature vector pairs. Store the results in a single file named “Distance.csv” with the following format:
# ## FV1_User FV2_User <DistanceMeasure_1> <DistanceMeasure_2>
# 
# ### Where, “FV1_User” and “FV2_User” columns are the User to whom the Feature Vectors (that are being compared) belong to and “<DistanceMeasure_1>” and “<DistanceMeasure_2>” are the results of applying the distance measure on the two vectors. (label the distance columns accordingly, for example if distance function is “Euclidean”, name the column “Euclidean_Distance”)
# 
# ### c) Briefly explain how the distance measures performed with the help of density curves for intra-user and inter-user distances.
# ### d) If you were to use the demographic information as features. How would you transform them to work with the distance measures? Briefly explain for each column (except “User”) in the “Demographics.csv” fil

# In[12]:


# read the feature vector
features_dist = pd.read_csv("FeaturesDF.csv")

features_dist=features_dist.drop(["User"],axis=1)


# In[13]:


features_dist.head()


# ## Correlation Heat map

# In[14]:


# Correlation heat map
# By default .corr uses Pearson correlation
sns.heatmap(features_dist.corr())

plt.title('Correlation Heat map Between Features')
plt.xlabel('Features')
plt.ylabel('Features')

plt.savefig("CorrelationHeatMap.png")
plt.show()


# ## I'm Taking Eucldian Distance and CityBlock distance
# ### Euclidean Distance
# #### * Euclidean Distance represents the shortest distance between two points.
# 
# ### CIty Block Distance or Manhattan distance
# #### * Manhattan distance is the absolute distance between two points
# #### Both Eclidian and Manhattan distance are derived from MINKOWSKI FOR DIFFERENT VALUES OF P:
# #### For, p=1, the distance measure is the Manhattan measure.
# #### p=2, the distance measure is the Euclidean measure.
# 

# ### Calculating distance using packages
# 

# In[15]:


from scipy.spatial.distance import pdist
ED=[]
MH=[]
ED=pdist(features_dist, 'euclidean')
MH=pdist(features_dist, 'cityblock')
print("Euclidian")
print(ED)
print("Manhattan")
print(MH)


# ### Calculate distance by direct formula
# 

# In[16]:


#features_dist
def Calculate_distance(features_dist):
    Euclidian = []
    manhattan = []
    usercol = ["A"]*5 +["B"]*5
    FV1user = []
    FV2user = []
    for i in range(0,10):
        for j in range (i+1,10):
            a = features_dist.iloc[i].tolist()
            b = features_dist.iloc[j].tolist()
            FV1user.append(usercol[i])
            FV2user.append(usercol[j])

            # Euclidian distance
            Euclidian.append(sum((colA-colB)**2 for colA, colB in zip(a, b)) ** .5)

            # Manhanttan distance

            manhattan.append(sum(abs((colA-ColB)) for colA, ColB in zip(a, b)))

    print("###################")
    print("Euclidian distance")
    print("###################")
    print(Euclidian)

    print("###################")
    print("Manhattan distance")
    print("###################")
    print(manhattan)
    print(FV1user)
    print(FV2user)
    distance_df = pd.DataFrame()

    distance_df["FV1_User"] = FV1user
    distance_df["FV2_User"] = FV2user

    distance_df["Euclidian_Distance"] = Euclidian
    distance_df["Manhattan_Distance"] = manhattan
    
    print("\n###########################")
    print("DISTANCE MEASURES")
    print("########################### \n")
    
    print(distance_df)
    print("###########################")
    
    return distance_df


# #### Creating distance dataframe

# In[17]:


distance_df = Calculate_distance(features_dist)


# In[18]:


distance_df.head()


# ### C Finding the Intra User and inter user density
# 

# ### Intra user density: between same user
# 

# In[19]:



# Intra User means FV1user = FV2user
# Filter data frame for intra user

Intrauser_distancedf = distance_df[distance_df["FV1_User"] == distance_df["FV2_User"]]
Intrauser_distancedf=Intrauser_distancedf.reset_index(drop = True)


print("###################")
print("Intra User distance")
print("###################")
print(Intrauser_distancedf)


# ### InterUser Distance between 2 different users

# In[20]:


# Inter User means FV1user != FV2user
# Filter data frame for inter user


Interuser_distancedf = distance_df[distance_df["FV1_User"] != distance_df["FV2_User"]]
Interuser_distancedf = Interuser_distancedf.reset_index(drop = True)

print("###################")
print("Inter User distance")
print("###################")
print(Interuser_distancedf)


# ### Plotting the density curve of users
# 

# In[21]:


#for i, user in enumerate(alldf.keys()):
sns.distplot(Intrauser_distancedf["Euclidian_Distance"], hist = False, kde = True, kde_kws = {'linewidth': 2},label = "Euclidian_Distance")
sns.distplot(Intrauser_distancedf["Manhattan_Distance"], hist = False, kde = True, kde_kws = {'linewidth': 2},label = "Manhattan_Distance")

plt.legend(prop={'size': 12}, title = 'Distance Name')
plt.title('Intra User Density Plot ')
plt.xlabel('Distance value ')
plt.ylabel('Density')
plt.savefig("Intra_User_DensityCurves.png")


# In[22]:


sns.distplot(Interuser_distancedf["Euclidian_Distance"], hist = False, kde = True, kde_kws = {'linewidth': 2},label = "Euclidian_Distance")
sns.distplot(Interuser_distancedf["Manhattan_Distance"], hist = False, kde = True, kde_kws = {'linewidth': 2},label = "Manhattan_Distance")

plt.legend(prop={'size': 12}, title = 'Distance Name')
plt.title('Inter User Density Plot ')
plt.xlabel('distance value ')
plt.ylabel('Density')
plt.savefig("Inter_User_DensityCurves.png")


# ## Part C explanation
# ### * From both distance measures i Find that 
# ### * Intra Distance measure values are small 
# ### * Inter Distance values are large
# ### * Both intra and inter distanc density curve look like gaussian distribution
# 

# ## Part d
# ### * If there is a categorical column then we can either transform that column to numerical using different techniques like one hot encoding etc. and then find the distance as usual
# ### or if there are only categorical variables we can use overlap method to find the distance
# ### If we have both numerical and categorical variables , then we follow heterogenous distance measure
# ### i.e. finding distance for numerical columns seperately and adding that with the distance value between categorical variables
# 

# ## Part D (30 Points): A simplistic matching attempt.
# ### a) Using the techniques from Part B, extract features from test-samples “Test1”, “Test2” and “Test3”.
# ### b) Using a distance measure from Part C, classify each test sample as either: “belongs to user A” or “belongs to user B”. Describe your method to arrive at a decision. 

# In[23]:


data_test_path = "C:\\Users\\hemal\\Desktop\\Masters\\SEM3\\Machine Learning\\Assignment\\Assignment1\\DataCIS735_Assignment1\\TestSamples"
allTestDf = read_df(data_test_path)


# In[24]:


allTestDf


# In[25]:


Final_feature_allTestdf =feature_extraction(allTestDf,name = "FeaturesTestDF") 


# ### Finding the distance values for test data

# In[26]:


# read the feature vector
features_dist_test = pd.read_csv("FeaturesTestDF.csv")

features_dist_test =features_dist_test.drop(["User"],axis=1)


# ## Now to find where each file of test data belong to, we find the distance between the test data and A, and test data and B which ever distance is small, the test file belong to that category

# In[27]:



traindf=pd.read_csv('Featuresdf.csv')
#divide the training features into A and B users

traindfA=traindf[:5]
traindfB=traindf[5:]


# In[28]:


features_dist


# In[29]:


features_dist_test


# In[30]:


merged = pd.concat([features_dist_test,features_dist]) # seperate User A alone
merged = merged.reset_index(drop = True)
merged


# In[31]:


mergedTestAndUserA = pd.concat([features_dist_test,features_dist[:5]]) # seperate User A alone
mergedTestAndUserA = mergedTestAndUserA.reset_index(drop = True)
mergedTestAndUserA


# In[32]:


mergedTestAndUserB = pd.concat([features_dist_test,features_dist[5:]]) # seperate User A alone
mergedTestAndUserB = mergedTestAndUserB.reset_index(drop = True)
mergedTestAndUserB


# In[33]:


ED=[]
MH=[]
ED=pdist(mergedTestAndUserA, 'euclidean')
MH=pdist(mergedTestAndUserA, 'cityblock')
print("Euclidian user A And test")
print(ED)
print("Manhattan User A and Test")
print(MH)

mergedTestAndUserA
ED=[]
MH=[]
ED=pdist(mergedTestAndUserB, 'euclidean')
MH=pdist(mergedTestAndUserB, 'cityblock')
print("Euclidian User B And test")
print(ED)
print("Manhattan User B and Test")
print(MH)


# In[34]:


User1 = []
User2 = []
usercol = ["T1","T2","T3"] + ["A"]*5 + ["B"]*5
Euclidian_test = []
manhattan_test = []
for i in range(0,12):
        for j in range (i+1,12):
            a = merged.iloc[i].tolist()
            b = merged.iloc[j].tolist()
            User1.append(usercol[i])
            User2.append(usercol[j])

            # Euclidian distance
            Euclidian_test.append(sum((colA-colB)**2 for colA, colB in zip(a, b)) ** .5)

            # Manhanttan distance

            manhattan_test.append(sum(abs((colA-ColB)) for colA, ColB in zip(a, b)))
distancetest_df = pd.DataFrame()

distancetest_df["User1"] = User1
distancetest_df["User2"] = User2

distancetest_df["Euclidian_Distance"] = Euclidian_test
distancetest_df["Manhattan_Distance"] = manhattan_test

print("\n###########################")
print("DISTANCE MEASURES")
print("########################### \n")

print(distancetest_df)
print("###########################")
    


# In[35]:


distancetest_df[distancetest_df["User1"] == "T1"]


# ### When we compare the pair wise distance between Test1 and User A and User B
# ### we find that the distance betweewn Test1 and User 1 is smaller than Test1 and USer 2
# ## so we conclude that Test 1 data belongs to USERA

# In[36]:


distancetest_df[distancetest_df["User1"] == "T2"]


# ### When we compare the pair wise distance between Test2 and User A and User B
# ### we find that the distance betweewn Test2 and User 1 is smaller than Test1 and USer 2
# ## so we conclude that Test 2 data belongs to USERA

# In[37]:


distancetest_df[distancetest_df["User1"] == "T3"]


# ### When we compare the pair wise distance between Test3 and User A and User B
# ### we find that the distance betweewn Test3 and User 2 is smaller than Test1 and USer 1
# ## so we conclude that Test 3 data belongs to USERB

# In[38]:


distancetest_df = distancetest_df[distancetest_df["User2"] != "T1"]
distancetest_df = distancetest_df[distancetest_df["User2"] != "T2"]
distancetest_df = distancetest_df[ distancetest_df["User2"] != "T3" ]
print(distancetest_df)  


# In[39]:


testlist = ["T1","T2","T3"]
for test in testlist:
    print (test)
    df_now = distancetest_df[distancetest_df["User1"] == test]
    #print(df_now)
    df_G =df_now.groupby(['User1','User2']).mean()
    print(df_G)
    #if df_G["Euclidian_Distance"]

